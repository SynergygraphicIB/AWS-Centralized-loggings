import gzip
import json
import base64
import boto3
import botocore


def assume_role_across_account(roleArn,region,servicio):    
    sts_connection = boto3.client('sts')
    
    acct_b = sts_connection.assume_role(
        RoleArn=roleArn,
        RoleSessionName="cross_acct_lambda"
    )
    
    ACCESS_KEY = acct_b['Credentials']['AccessKeyId']
    SECRET_KEY = acct_b['Credentials']['SecretAccessKey']
    SESSION_TOKEN = acct_b['Credentials']['SessionToken']
    client = boto3.client(servicio , region_name = region, aws_access_key_id = ACCESS_KEY, aws_secret_access_key = SECRET_KEY ,aws_session_token = SESSION_TOKEN)
    
    return client


def delete_existing_subscription_filter( log_group_name,log_client):
    # Retrieve any existing subscription filters (only can be one)
    subscription_filters = log_client.describe_subscription_filters(
        logGroupName=log_group_name)

    # Iterate over results if there are any (again, should not be multiple, but to follow the convention of the SDK)
    for subscription_filter in subscription_filters['subscriptionFilters']:
        # Retrieve the subscription filter name to use in the call to delete
        filter_name = subscription_filter['filterName']

        # Delete any subscriptions that are found on the log group
        log_client.delete_subscription_filter(
            logGroupName=log_group_name,
            filterName=filter_name
        )
        
def add_subscription_filter( log_group_name ,log_client,ssm_client):
    # Retrieve the destination for the subscription from the Parameter Store
    destination_response = ssm_client.get_parameter(Name='LogDestination')

    # Error if no destination, otherwise extract destination id from response
    if not destination_response:
        raise ValueError(
            'Cannot locate central logging destination, put_subscription_filter failed')
    else:
        destination = destination_response['Parameter']['Value']
        

    # Error to try to add subscription if one already exists, so delete any existing subscription from this log group
    delete_existing_subscription_filter(log_group_name,log_client)

    # Put the new subscription with the destination onto the log group
    log_client.put_subscription_filter(
        logGroupName=log_group_name,
        filterName='Destination',
        filterPattern='',
        destinationArn=destination
    )

def lambda_handler(event, context):
    ssm_client = boto3.client('ssm')
    arn_assume = ssm_client.get_parameter(Name='LogArnAssume')

    # Error if no arn, otherwise extract  id from response
    if not arn_assume:
        raise ValueError(
            'Cannot locate central arn assume rol, failed')
    else:
        arn_assume = arn_assume['Parameter']['Value']

    if(event.get("awslogs")):
        cw_data = event['awslogs']['data']
        compressed_payload = base64.b64decode(cw_data)
        uncompressed_payload = gzip.decompress(compressed_payload)
        payload = json.loads(uncompressed_payload)
        
        logGroup = payload["logGroup"]
        logStream = payload["logStream"]
        
        log_events = payload['logEvents']
        try:
            client_assume_role = assume_role_across_account(arn_assume,"us-east-1","logs")    
    
            for log_event in log_events:
                del log_event["id"]
     
                response = client_assume_role.put_log_events(
                    logGroupName=logGroup,
                    logStreamName=logStream,
                    logEvents=[
                        log_event
                    ]
                )
        except botocore.exceptions.ClientError as error:
            print("Boto3 API returned error: ", error)
            
    elif(event.get("detail")):
        event=event.get("detail")
        if(event["eventName"]== "CreateLogGroup"):
            LogGroupName = event["requestParameters"]["logGroupName"]
            try:
                log_client = boto3.client('logs')
                ssm_client = boto3.client('ssm')
                add_subscription_filter(LogGroupName,log_client,ssm_client)
                client_assume_role = assume_role_across_account(arn_assume,"us-east-1","logs")    
                response = client_assume_role.create_log_group(  logGroupName = LogGroupName)
            except botocore.exceptions.ClientError as error:
                print("Boto3 API returned error: ", error)
                
        elif(event["eventName"]== "CreateLogStream"):
            try:
                client_assume_role = assume_role_across_account(arn_assume,"us-east-1","logs")    
                LogGroupName = event["requestParameters"]["logGroupName"]
                LogStreamName = event["requestParameters"]["logStreamName"]

                response = client_assume_role.create_log_stream(
                        logGroupName= LogGroupName,
                        logStreamName= LogStreamName
                )
                print(response)
      
            except botocore.exceptions.ClientError as error:
                print("Boto3 API returned error: ", str(error))

                if("ResourceNotFoundException" in str(error)):
                    try:
                        LogGroupName = event["requestParameters"]["logGroupName"]
                        LogStreamName = event["requestParameters"]["logStreamName"]
                        client_assume_role = assume_role_across_account(arn_assume,"us-east-1","logs")    
                        response = client_assume_role.create_log_group(logGroupName = LogGroupName)
                        log_client = boto3.client('logs')
                        ssm_client = boto3.client('ssm')
                        add_subscription_filter(LogGroupName,log_client,ssm_client)
                        response = client_assume_role.create_log_stream(
                            logGroupName= LogGroupName,
                            logStreamName= LogStreamName
                        )
                    except botocore.exceptions.ClientError as error:
                        print("Boto3 API returned error: ", "OLL")

                        
        